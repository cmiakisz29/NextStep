# NextStep — launch version

## What this is
A publishable static MVP for NextStep: a goal-planning website with a free tier, progress tracking, and a prepared NextStep Pro subscription button.

## 1. Test it
Open `index.html` in Safari, Chrome, or another browser.

## 2. Put it on the internet
Upload this folder/ZIP to a static web host. Vercel is one option and can deploy a static site. Once hosted, the site receives a public URL that works in Safari and other browsers.

## 3. Connect a domain
Buy a domain you like (for example a variation of the NextStep name if available) and connect it to the host. Domain availability and trademark issues should be checked before committing to a brand/domain.

## 4. Turn on subscriptions
The site intentionally does NOT contain secret payment keys.

A simple launch path:
1. Set up a Stripe account. If the business owner is under 18, complete Stripe's required legal-guardian ownership/verification steps.
2. In Stripe, create a product named "NextStep Pro".
3. Add a recurring monthly price. The website currently displays $7.99/month; change the site if you choose a different real price.
4. Create a Stripe Payment Link for that recurring subscription.
5. Open `index.html`.
6. Find `YOUR_STRIPE_PAYMENT_LINK`.
7. Replace it with the real HTTPS Payment Link.
8. Re-upload/redeploy the site.

## Important limitation
The current site can ACCEPT a subscription after the Payment Link is connected, but it does not yet securely authenticate subscribers or automatically unlock Pro-only software features. Real gated Pro features require a backend, user accounts, a database, and payment-status verification/webhooks. Do not claim those features are live until that system is built.

## Before taking real customers
Add final Terms, Privacy Policy, refund/cancellation information, support contact information, and make sure recurring-price/cancellation disclosures match the actual payment setup and applicable rules.

## Files
- index.html — website
- styles.css — design
- app.js — roadmap/progress logic
